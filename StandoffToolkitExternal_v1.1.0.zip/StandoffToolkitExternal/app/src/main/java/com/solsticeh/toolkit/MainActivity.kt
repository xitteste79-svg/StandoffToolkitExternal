package com.solsticeh.toolkit

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(21, 25, 34)
    private val red = Color.rgb(255, 67, 83)
    private val muted = Color.rgb(153, 164, 181)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
        }
        scroll.addView(root)

        root.addView(label("SOLSTICE-H  /  EXTERNAL", 12, red, true))
        root.addView(label("STANDOFF TOOLKIT", 28, Color.WHITE, true))
        root.addView(label("ADVANCED CONTROL PANEL  •  v1.1.0", 11, muted, false))
        root.addView(gap(20))
        root.addView(section("SYSTEM STATUS"))
        root.addView(card("DEVICE", "Android ${android.os.Build.VERSION.RELEASE}  •  ${android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "Unknown ABI"}"))
        root.addView(card("NATIVE CORE", nativeBuildInfo()))
        root.addView(card("DATA SOURCE", "Local deterministic mock replay — no game connection"))
        root.addView(gap(12))
        root.addView(section("CONTROL CENTER"))
        root.addView(action("LAUNCH FLOATING TRAINER") { startOverlay() })
        root.addView(action("OVERLAY PERMISSION") { requestOverlayPermission() })
        root.addView(action("STOP FLOATING TRAINER") {
            stopService(Intent(this, OverlayService::class.java))
        })
        root.addView(gap(12))
        root.addView(section("DIAGNOSTIC MODULES"))
        root.addView(card("ESP VISUALIZER", "Synthetic boxes, skeletal lines, labels and health bars."))
        root.addView(card("RADAR", "Top-down view of generated local entities."))
        root.addView(card("AIM TRAINER", "Tap moving targets and track accuracy locally."))
        root.addView(card("ROOT STATUS", "No root required. No privileged commands are executed."))
        root.addView(gap(18))
        root.addView(label(
            "Standalone offline visualization only. This app does not inspect, modify, inject into, or automate Standoff 2.",
            12, muted, false
        ))
        setContentView(scroll)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        startService(Intent(this, OverlayService::class.java))
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ))
        }
    }

    private fun section(s: String) = label(s, 12, red, true).apply {
        setPadding(0, 8, 0, 10)
    }

    private fun card(title: String, body: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 13, 16, 13)
            setBackgroundColor(panel)
        }
        box.addView(label(title, 11, red, true))
        box.addView(label(body, 13, Color.WHITE, false))
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 }
        return box
    }

    private fun action(s: String, f: () -> Unit): View =
        Button(this).apply {
            text = s
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(150, 34, 49))
            setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 }
        }

    private fun label(s: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 3, 0, 3)
        }

    private fun gap(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, h)
    }

    private external fun nativeBuildInfo(): String

    companion object {
        init { System.loadLibrary("sht_native") }
    }
}
