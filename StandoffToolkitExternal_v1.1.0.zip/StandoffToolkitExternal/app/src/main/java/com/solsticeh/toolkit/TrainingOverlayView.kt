package com.solsticeh.toolkit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.random.Random

private data class MockEntity(
    var x: Float, var y: Float, val phase: Float, val health: Float
)

class TrainingOverlayView(context: Context) : View(context) {
    private val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(238, 10, 13, 19) }
    private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 67, 83); style = Paint.Style.STROKE; strokeWidth = 2.5f
    }
    private val redFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(45, 255, 67, 83) }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 25f; typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val muted = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; textSize = 16f }
    private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(65, 220, 140); strokeWidth = 5f }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(35, 180, 190, 210); strokeWidth = 1f }
    private val entities = mutableListOf<MockEntity>()
    private var hits = 0
    private var shots = 0
    private var last = "Tap the highlighted training target"
    private var targetIndex = 0
    private var tick = 0
    private val density = resources.displayMetrics.density

    init {
        repeat(4) { i ->
            entities += MockEntity(0.22f + i * 0.18f, 0.47f + (i % 2) * 0.08f, i * 1.7f, 0.55f + i * 0.1f)
        }
        targetIndex = Random.nextInt(entities.size)
        post(object : Runnable {
            override fun run() {
                tick++
                entities.forEachIndexed { i, e ->
                    e.x = (0.22f + i * 0.18f + 0.035f * kotlin.math.sin(tick * 0.035f + e.phase))
                        .coerceIn(0.12f, 0.88f)
                    e.y = (0.46f + 0.07f * kotlin.math.cos(tick * 0.028f + e.phase))
                        .coerceIn(0.30f, 0.72f)
                }
                invalidate()
                postDelayed(this, 33L)
            }
        })
    }

    private fun px(v: Float) = v * density

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), px(18f), px(18f), background)
        c.drawText("SHT  /  SPATIAL TELEMETRY", px(18f), px(30f), white)
        c.drawText("LOCAL MOCK REPLAY  •  NO GAME DATA", px(18f), px(53f), muted)
        c.drawText("HITS $hits    SHOTS $shots    ACC ${if (shots == 0) 0 else hits * 100 / shots}%", px(18f), px(82f), white)

        val left = width * 0.04f
        val top = height * 0.19f
        val right = width * 0.72f
        val bottom = height * 0.86f
        for (i in 1..4) {
            val x = left + (right - left) * i / 5f
            c.drawLine(x, top, x, bottom, grid)
        }
        for (i in 1..4) {
            val y = top + (bottom - top) * i / 5f
            c.drawLine(left, y, right, y, grid)
        }

        entities.forEachIndexed { index, e ->
            val cx = width * e.x
            val cy = height * e.y
            val boxW = px(43f)
            val boxH = px(88f)
            val rect = RectF(cx - boxW, cy - boxH, cx + boxW, cy + boxH)
            c.drawRoundRect(rect, px(5f), px(5f), if (index == targetIndex) redFill else grid)
            c.drawRoundRect(rect, px(5f), px(5f), if (index == targetIndex) red else muted.apply { style = Paint.Style.STROKE; strokeWidth = px(1.5f) })

            // Synthetic skeleton: head, torso, arms and legs.
            val joint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (index == targetIndex) Color.rgb(255, 90, 105) else Color.LTGRAY
                strokeWidth = px(2f)
            }
            val headY = cy - px(64f)
            val hipY = cy + px(25f)
            c.drawCircle(cx, headY, px(10f), joint)
            c.drawLine(cx, headY + px(10f), cx, hipY, joint)
            c.drawLine(cx, cy - px(22f), cx - px(25f), cy + px(2f), joint)
            c.drawLine(cx, cy - px(22f), cx + px(25f), cy + px(2f), joint)
            c.drawLine(cx, hipY, cx - px(20f), cy + px(68f), joint)
            c.drawLine(cx, hipY, cx + px(20f), cy + px(68f), joint)
            c.drawText("SIM-${index + 1}", cx - px(25f), cy - boxH - px(9f), muted)
            c.drawRect(cx - boxW - px(9f), cy - boxH, cx - boxW - px(5f), cy + boxH, grid)
            green.strokeWidth = px(4f)
            c.drawLine(cx - boxW - px(7f), cy + boxH, cx - boxW - px(7f),
                cy + boxH - boxH * e.health.coerceIn(0f, 1f), green)
        }

        // Radar panel.
        val radarCx = width * 0.84f
        val radarCy = height * 0.48f
        val radarR = px(66f)
        c.drawCircle(radarCx, radarCy, radarR, grid)
        c.drawLine(radarCx - radarR, radarCy, radarCx + radarR, radarCy, grid)
        c.drawLine(radarCx, radarCy - radarR, radarCx, radarCy + radarR, grid)
        entities.forEachIndexed { i, e ->
            val dx = (e.x - 0.5f) * radarR * 1.7f
            val dy = (e.y - 0.5f) * radarR * 1.7f
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (i == targetIndex) Color.rgb(255, 67, 83) else Color.WHITE
            }
            c.drawCircle(radarCx + dx, radarCy + dy, px(4f), dot)
        }
        c.drawText("RADAR", radarCx - px(24f), radarCy + radarR + px(22f), muted)
        c.drawText(last, px(18f), height - px(18f), muted)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            shots++
            val e = entities[targetIndex]
            val tx = width * e.x
            val ty = height * e.y
            if (hypot(event.x - tx, event.y - ty) <= px(58f)) {
                hits++
                last = "HIT  •  NICE SHOT"
                targetIndex = (targetIndex + 1) % entities.size
            } else {
                last = "MISS  •  TRY AGAIN"
            }
            invalidate()
            return true
        }
        return true
    }
}
