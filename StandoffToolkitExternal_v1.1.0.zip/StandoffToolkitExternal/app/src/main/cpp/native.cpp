#include <jni.h>
#include <string>
#include <string_view>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_solsticeh_toolkit_MainActivity_nativeBuildInfo(
    JNIEnv* env, jobject /* thiz */) {
#if defined(__aarch64__)
    constexpr std::string_view abi = "ARM64-v8a";
#else
    constexpr std::string_view abi = "ABI-unknown";
#endif
    const std::string info = "C++20 native core | " + std::string(abi) + " | offline";
    return env->NewStringUTF(info.c_str());
}
