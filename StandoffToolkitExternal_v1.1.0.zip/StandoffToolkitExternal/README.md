# Standoff Toolkit External APK — v1.1.0

Independent Android overlay with a local synthetic scene and tap trainer.

## Included
- Advanced dark/red control panel.
- Separate Android overlay service.
- Animated mock entities with boxes, labels, synthetic skeleton lines and health bars.
- 2D radar of synthetic entities.
- Local tap trainer with hit, shot and accuracy counters.
- C++20 JNI native-core/ABI diagnostic.
- ARM64-only native build configuration.

## Safety boundary
This is an offline visualizer and trainer. It does not connect to Standoff 2,
read or modify game memory, inject code, automate aiming in matches, or bypass
anti-cheat. Root is not required and no root command is executed.

## Build requirements
- JDK 17
- Android Studio / Gradle
- Android SDK Platform 35
- Android NDK
- CMake 3.22.1 or newer

Open the project folder in Android Studio and allow Gradle sync.
Then choose Build > Build Bundle(s) / APK(s) > Build APK(s).

The application is configured for arm64-v8a, minSdk 26 and targetSdk 35.
On first launch, use OVERLAY PERMISSION and grant "Display over other apps".
Then press LAUNCH FLOATING TRAINER.

## MT Manager note
MT Manager can inspect, sign, and install a built APK. It is not by itself
a full Android Gradle/NDK build environment. Build with Android Studio or
a configured Gradle + SDK + NDK environment, then copy the APK to the phone.
